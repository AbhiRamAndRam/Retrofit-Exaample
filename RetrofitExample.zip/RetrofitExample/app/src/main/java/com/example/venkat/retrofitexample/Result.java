package com.example.venkat.retrofitexample;

import java.util.List;

/**
 * Created by venkat on 11/26/16.
 */

public class Result {

    private List<Speacility>specialities;
    private List<Languages>languages;
    private List<Qualifications>qualificationsList;
    private List<States>states;
    private List<Countries>countries;
    private List<Services>clinicServices;

    public List<Services> getClinicServices() {
        return clinicServices;
    }

    public void setClinicServices(List<Services> clinicServices) {
        this.clinicServices = clinicServices;
    }

    public List<States> getStates() {
        return states;
    }

    public void setStates(List<States> states) {
        this.states = states;
    }

    public List<Countries> getCountries() {
        return countries;
    }

    public void setCountries(List<Countries> countries) {
        this.countries = countries;
    }

    public List<Qualifications> getQualificationsList() {
        return qualificationsList;
    }

    public void setQualificationsList(List<Qualifications> qualificationsList) {
        this.qualificationsList = qualificationsList;
    }

    public List<Languages> getLanguages() {
        return languages;
    }

    public void setLanguages(List<Languages> languages) {
        this.languages = languages;
    }

    public List<Speacility> getSpecialities() {
        return specialities;
    }

    public void setSpecialities(List<Speacility> specialities) {
        this.specialities = specialities;
    }
}
