package com.example.venkat.retrofitexample;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;


/**
 * Created by venkat on 11/26/16.
 */

public interface RetrofitGetAPI {

    @GET("api/RetrofitProfileResponse")
    Call<List<CardTypes>> getProfileData();
}
