package com.example.venkat.retrofitexample;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {

    String url = "My Url";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();

        // set your desired log level
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        final OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .readTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(url).
                addConverterFactory(GsonConverterFactory.create()).build();


        RetrofitGetAPI service = retrofit.create(RetrofitGetAPI.class);



//
//
//        call.enqueue(new Callback<List<CardTypes>>() {
//            @Override
//            public void onResponse(Response<List<CardTypes>> response, Retrofit retrofit) {
//                System.out.println("Response is=====>" + response.body());
//            }
//
//            @Override
//            public void onFailure(Throwable t) {
//                System.out.println("Failure response is====>");
//            }
//        });
    }
}
