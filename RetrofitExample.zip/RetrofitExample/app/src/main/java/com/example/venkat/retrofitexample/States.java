package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class States {

    private int stateid;

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStateid() {
        return stateid;
    }

    public void setStateid(int stateid) {
        this.stateid = stateid;
    }

    private int cid;
    private String name;
}
