package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class Qualifications {

    public int getQualtypeid() {
        return qualtypeid;
    }

    public void setQualtypeid(int qualtypeid) {
        this.qualtypeid = qualtypeid;
    }

    public String getQualificationname() {
        return qualificationname;
    }

    public void setQualificationname(String qualificationname) {
        this.qualificationname = qualificationname;
    }

    private int qualtypeid;
    private String qualificationname;
}
