package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class Languages {

    public int getLangtypeid() {
        return langtypeid;
    }

    public void setLangtypeid(int langtypeid) {
        this.langtypeid = langtypeid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private int langtypeid;
    private String name;
}
