package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class Speacility {

    private int specialitytypeid;
    private String specialityname;

    public String getSpecialityname() {
        return specialityname;
    }

    public void setSpecialityname(String specialityname) {
        this.specialityname = specialityname;
    }

    public int getSpecialitytypeid() {
        return specialitytypeid;
    }

    public void setSpecialitytypeid(int specialitytypeid) {
        this.specialitytypeid = specialitytypeid;
    }
}
