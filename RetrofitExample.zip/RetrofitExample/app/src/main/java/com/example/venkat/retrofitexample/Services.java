package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class Services {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    private int id;
    private String servicename;
}
