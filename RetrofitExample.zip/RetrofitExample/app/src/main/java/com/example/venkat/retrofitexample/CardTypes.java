package com.example.venkat.retrofitexample;

/**
 * Created by venkat on 11/26/16.
 */

public class CardTypes {

    private int paymenttypeid;
    private String cardType;

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getPaymenttypeid() {
        return paymenttypeid;
    }

    public void setPaymenttypeid(int paymenttypeid) {
        this.paymenttypeid = paymenttypeid;
    }
}
